from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'TTree_136TeV_mm_2022D'
config.General.transferOutputs = True
config.General.transferLogs = False
config.section_('JobType')
config.JobType.outputFiles = ['Muon_Run2022D_v1_Data.root']
config.JobType.psetName = 'miniAODmuonsRootupler_2022_D.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.totalUnits = -1
config.Data.publication = False
config.Data.unitsPerJob = 50
config.Data.inputDataset = '/Muon/Run2022D-22Sep2023-v1/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.outLFNDirBase = '/store/user/nkarunar/'
config.Data.inputDBS = 'global'
config.Data.splitting = 'LumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_US_FNALLPC'
config.section_('User')
config.section_('Debug')
