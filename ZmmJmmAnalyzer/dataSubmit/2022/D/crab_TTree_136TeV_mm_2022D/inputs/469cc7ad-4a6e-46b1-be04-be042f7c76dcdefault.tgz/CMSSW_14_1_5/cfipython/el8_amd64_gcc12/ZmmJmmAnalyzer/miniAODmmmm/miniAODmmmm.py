import FWCore.ParameterSet.Config as cms

def miniAODmmmm(**kwargs):
  mod = cms.EDAnalyzer('miniAODmmmm',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
